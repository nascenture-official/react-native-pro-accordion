# react-native-pro-accordion

Enterprise-grade React Native accordion component with advanced animations, accessibility support, and theme system.

## Features

- ✅ **Multiple Modes**: Single or multiple expand modes
- ✅ **Controlled & Uncontrolled**: Flexible state management
- ✅ **Advanced Animations**: Spring & timing animations with Reanimated v3
- ✅ **Accessibility**: Screen reader & keyboard navigation support
- ✅ **Theme System**: Light/dark mode with custom theming
- ✅ **Performance**: Memoized components & lazy rendering
- ✅ **TypeScript Ready**: Full JSDoc support
- ✅ **No Native Dependencies**: Pure JavaScript solution

## Installation

```bash
npm install react-native-pro-accordion react-native-reanimated
```
